#include "GLOBALS.h"

inline uint8_t hexval(char x) { return x <= '9' ? x - '0' : (x & 0xDF) - 'A' + 10; }

inline void set_SDLed(bool state){
  sdled = state;
  digitalWrite(SD_LED, sdled);
}
inline void troggle_SDLed(){
  set_SDLed(!sdled);
}

void set_status_LED(uint8_t R,uint8_t G, uint8_t B){
#ifdef COMMON_ANODE
  analogWrite(ST_LED_R, (0xff-R)*1/1); 
  analogWrite(ST_LED_G, (0xff-G)*1/10); 
  analogWrite(ST_LED_B, (0xff-B)*1/2); 
#else
  analogWrite(ST_LED_R, R*1/1); 
  analogWrite(ST_LED_G, G*1/4); 
  analogWrite(ST_LED_B, B*1/8); 
#endif
}

void set_status_LED(uint32_t RGB){
//  set_status_LED((RGB >> 16)&0xff, (RGB >> 8)&0xff, RGB & 0xff);
  set_status_LED((RGB >> 16)&0xff, (RGB >> 8)&0xff, RGB & 0xff);
}

void LED_error(uint32_t RGB1, uint32_t RGB2){
    while (1) {
      set_status_LED(RGB1);
      delay(500);
      set_status_LED(RGB2);  
      delay(500);
     }
}
void LED_error(uint32_t RGB){
  LED_error(RGB, clRED);
}

void split_two_params(char* params, char* param1, char* param2){
  int i,j;
  for (i=0; params[i]!=' '; i++){
    if (params[i]!=0)
      param1[i]=params[i];
    else break;
  }
  param1[i]=0;
  if (params[i]!=0){
    i++;
    for (j=i;(params[j]!=0); j++){
      param2[j-i]=params[j];
    }
    param2[j-i]=0;
  } else param2[0]=0;
}

void hex_to_str(char* v, char* params){
  uint8_t i;
  uint8_t len = strlen(params);
  for (i=0; i<len/2;i++){
    sscanf(params, "%2hhx", v+i);
    params+=2;
  }
  v[i]=0;
}

void upStr(char* s){
  for (int i=0; s[i]!=0; i++){
    s[i] = toupper(s[i]);
  }
}

#if defined(LOG0)||defined(LOG1)||defined(LOG2)||defined(LOG3)
void log_debug(const char* fmt PROGMEM, ...)
{
char S[60];
    va_list arg;
    va_start(arg, fmt);

    vsprintf_P(S,fmt, arg); 
    //vprintf can be replaced with vsprintf (for sprintf behavior) 
    //or any other printf function preceded by a v
    Serial.println(S);

    va_end(arg);
}
#endif

void start_reset_Z80(){
  digitalWrite(Z80_RESET, LOW);
  pinMode(Z80_RESET, OUTPUT);
  digitalWrite(Z80_RESET, LOW);
}

void end_reset_Z80(){
  pinMode(Z80_RESET, INPUT);
  digitalWrite(Z80_RESET, HIGH);
}
